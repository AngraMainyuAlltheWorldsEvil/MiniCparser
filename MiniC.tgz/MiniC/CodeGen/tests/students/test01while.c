#include "printlib.h"

int main() {
    
    int x,y,z;
    x=4;
    y=0;
    z=0;
    while (x+1>y)
    {
       y=y+1;
    }
    println_int(y);
    return 0;
}

// EXPECTED
// 5
