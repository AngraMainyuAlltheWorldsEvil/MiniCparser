#include "printlib.h"

int main() {
    
   
    bool t2;
    t2=false;
    println_bool(t2);
    return 0;
}

// EXPECTED
// 0


