#include "printlib.h"
int main(){
//println_int(1 / 0);
bool t1,t2;
t1=true;
t2=false;
if(!t2)
{
    println_int(1);
}
return 0;
}
// EXPECTED
// 1