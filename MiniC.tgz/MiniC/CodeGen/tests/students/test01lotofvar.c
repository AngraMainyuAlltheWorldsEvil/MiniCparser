#include "printlib.h"
int main(){
//println_int(1 / 0);
int  a,b,c,d,e,g,f;
a=0;
b=1;
c=2;
d=3;
e=4;
f=5;
g=6;
println_int(a);
println_int(b);
println_int(c);
println_int(d);
println_int(e);
println_int(f);
println_int(g);



return 0;
}
// EXPECTED
// 0
// 1
// 2
// 3
// 4
// 5 
// 6 