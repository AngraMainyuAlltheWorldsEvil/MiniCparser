#include "printlib.h"
#include <stdio.h>

int main() {
    int i;
    int j;
    int x;
    j=0;
    i=0;
    
   
  for( i=0;i<1;i=i+1) x=42;
  println_int(x);
    return 0;
}

// EXPECTED
// 42
