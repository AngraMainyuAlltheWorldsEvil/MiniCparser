#include "printlib.h"

int main() {
    int i;
    int j;
    int x;
    j=0;
   
    
   for(i=0;i<2;i=i+1)
    {
       //println_int(i);
       //printf("%d", i);
       println_int(i+5);
       continue;
       println_int(i);
    }
 // for(;;) x=42;
  
    return 0;
}

// EXPECTED
// 5
// 6
