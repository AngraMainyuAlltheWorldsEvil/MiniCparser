#include "printlib.h"

int main() {
    int i;
    int j;
    int x;
    j=0;
   
    
   for(i=0;i<1;i=i+1)
    {
        println_int(i);
        for( j=0;j<1;j=j+1)
        {
            continue;
            println_int(j);
        }
    }
  
    return 0;
}

// EXPECTED
// 0
