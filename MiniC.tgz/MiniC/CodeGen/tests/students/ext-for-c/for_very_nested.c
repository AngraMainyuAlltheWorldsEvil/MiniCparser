#include "printlib.h"

int main() {
    int i;
    int j;
    int k;
    int c;

    for(i = 0; i < 1; i = i + 1)
    for(j = 0; j < 1; j = j + 1)
    for(k = 0; k < 1; k = k + 1)
    for(c = 0; c < 1; c = c + 1)
    {
        continue;
        println_int(c);
    }

    return 0;
}

// EXPECTED
