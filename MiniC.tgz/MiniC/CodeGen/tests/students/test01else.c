#include "printlib.h"
int main(){
//println_int(1 / 0);
bool t1,t2;
t1=true;
t2=true;
if(t1!=t2)
{
    println_int(1);
}
else
{
    println_int(0);
}
return 0;
}
// EXPECTED
// 0