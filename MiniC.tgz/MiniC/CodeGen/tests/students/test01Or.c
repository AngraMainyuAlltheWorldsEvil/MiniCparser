#include "printlib.h"

int main() {
    
   
    bool t1,t2;
    t2=false;
    t1=false;
    if(t2==false || t1==false )
    {
        println_int(1);
    }
    return 0;
}

// EXPECTED
// 1


