#include "printlib.h"

int main() {
    
    int x,y;
    x=4;
    y=5;
    println_bool(x==y);
    return 0;
}

// EXPECTED
// 0
