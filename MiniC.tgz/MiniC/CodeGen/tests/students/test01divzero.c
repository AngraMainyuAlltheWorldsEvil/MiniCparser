#include "printlib.h"
int main(){
//println_int(1 / 0);
    int x,y;
    x=4;
    y=0;
    println_int(4/0);
    return 0;
}
// SKIP TEST EXPECTED
// EXECCODE 1
// EXPECTED
// Division by 0