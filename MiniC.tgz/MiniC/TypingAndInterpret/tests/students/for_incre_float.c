#include "printlib.h"

int main(){
  float i;
  for (i = 0.0; i < 3.0; i = i + 1.0) {
    println_int(i);
  }
  return 0;
}
// EXITCODE 2
// EXPECTED
// In function main: Line 6 col 4: invalid type for println_int statement: float