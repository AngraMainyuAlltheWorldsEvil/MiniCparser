#include "printlib.h"

int main(){
  float i;
  for (i = 0.0; i < 3; i = i + 1) {
    println_int(i);
  }
  return 0;
}
// EXITCODE 2
// EXPECTED
// In function main: Line 5 col 16: invalid type for relational operands: float and integer