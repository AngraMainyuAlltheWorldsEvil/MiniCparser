#include "printlib.h"

int main(){
  float i;
  for (i = 0.0; i ; i = i + 1.0) {
    println_int(i);
  }
  return 0;
}
// EXITCODE 2
// EXPECTED
// In function main: Line 5 col 2: invalid type for for condition: float